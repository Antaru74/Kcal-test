package com.kcal.module;

/**
 * Setelan KCAL. Nama, rentang, dan default sama dengan aplikasi Clover
 * (lihat ulquiorra_kcal_preferences.xml). Dipakai oleh app DAN hook system_server,
 * jadi hanya boleh berisi Java murni (tanpa API Android).
 */
public final class KcalConfig {

    /** Setting Secure tempat app menulis konfigurasi, dibaca oleh hook. */
    public static final String SETTING_KEY = "kcal_module_config";
    /** Setting Secure tempat hook menulis balik konfigurasi yang berhasil diterapkan. */
    public static final String SETTING_ACK = "kcal_module_ack";

    public static final int CH_MIN = 0, CH_MAX = 256, CH_DEF = 256;          // R, G, B
    public static final int MIN_MIN = 35, MIN_MAX = 256, MIN_DEF = 35;       // kcal_min
    public static final int SAT_MIN = 128, SAT_MAX = 383, SAT_DEF = 255;     // kcal_sat
    public static final int VAL_MIN = 128, VAL_MAX = 383, VAL_DEF = 255;     // kcal_val
    public static final int CONT_MIN = 128, CONT_MAX = 383, CONT_DEF = 255;  // kcal_cont
    public static final int HUE_MIN = 0, HUE_MAX = 1536, HUE_DEF = 0;        // kcal_hue

    /** Standar, Hangat, Dingin, Malam (nilai RGB persis dari PRESET_RGB aplikasi asli). */
    public static final int[][] PRESETS = {
            {256, 256, 256},
            {256, 248, 225},
            {232, 244, 256},
            {256, 230, 190},
    };

    public boolean enabled;
    public boolean invert;
    public int red = CH_DEF;
    public int green = CH_DEF;
    public int blue = CH_DEF;
    public int min = MIN_DEF;
    public int sat = SAT_DEF;
    public int hue = HUE_DEF;
    public int val = VAL_DEF;
    public int cont = CONT_DEF;

    public KcalConfig copy() {
        KcalConfig c = new KcalConfig();
        c.enabled = enabled;
        c.invert = invert;
        c.red = red;
        c.green = green;
        c.blue = blue;
        c.min = min;
        c.sat = sat;
        c.hue = hue;
        c.val = val;
        c.cont = cont;
        return c;
    }

    public static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Indeks preset yang cocok dengan RGB ini, atau -1 kalau custom. */
    public static int indexOfPreset(int r, int g, int b) {
        for (int i = 0; i < PRESETS.length; i++) {
            if (PRESETS[i][0] == r && PRESETS[i][1] == g && PRESETS[i][2] == b) return i;
        }
        return -1;
    }

    /**
     * Format: v1;enabled;r;g;b;min;sat;hue;val;cont;invert;stamp
     * {@code stamp} dibuat berbeda di setiap pengiriman supaya perubahan selalu
     * memicu observer dan hook bisa membalas dengan string yang persis sama (ack).
     */
    public String serialize(long stamp) {
        return "v1;" + (enabled ? 1 : 0) + ";" + red + ";" + green + ";" + blue
                + ";" + min + ";" + sat + ";" + hue + ";" + val + ";" + cont
                + ";" + (invert ? 1 : 0) + ";" + stamp;
    }

    /** @return konfigurasi, atau null bila format tidak valid. */
    public static KcalConfig parse(String s) {
        if (s == null) return null;
        String[] p = s.trim().split(";");
        if (p.length < 11 || !"v1".equals(p[0])) return null;
        try {
            KcalConfig c = new KcalConfig();
            c.enabled = Integer.parseInt(p[1]) != 0;
            c.red = clamp(Integer.parseInt(p[2]), CH_MIN, CH_MAX);
            c.green = clamp(Integer.parseInt(p[3]), CH_MIN, CH_MAX);
            c.blue = clamp(Integer.parseInt(p[4]), CH_MIN, CH_MAX);
            c.min = clamp(Integer.parseInt(p[5]), MIN_MIN, MIN_MAX);
            c.sat = clamp(Integer.parseInt(p[6]), SAT_MIN, SAT_MAX);
            c.hue = clamp(Integer.parseInt(p[7]), HUE_MIN, HUE_MAX);
            c.val = clamp(Integer.parseInt(p[8]), VAL_MIN, VAL_MAX);
            c.cont = clamp(Integer.parseInt(p[9]), CONT_MIN, CONT_MAX);
            c.invert = Integer.parseInt(p[10]) != 0;
            return c;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
