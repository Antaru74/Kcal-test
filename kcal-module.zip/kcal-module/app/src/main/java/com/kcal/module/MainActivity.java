package com.kcal.module;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.materialswitch.MaterialSwitch;

/**
 * UI KCAL. Urutan mengikuti aplikasi asli: preset, aktif, invert, RGB, saturasi,
 * hue, value, kontras, lalu lanjutan (minimum, reset).
 */
public class MainActivity extends AppCompatActivity {

    private final Handler main = new Handler(Looper.getMainLooper());
    private KcalStore store;
    private KcalConfig cfg = new KcalConfig();

    private volatile boolean available = true; // false bila setelan tidak bisa ditulis
    private boolean refreshing;                // true saat UI diisi lewat kode

    private TextView status;
    private MaterialSwitch enableSwitch;
    private MaterialSwitch invertSwitch;
    private MaterialButtonToggleGroup presetGroup;
    private final int[] presetIds = new int[KcalConfig.PRESETS.length];
    private MaterialButton resetButton;
    private SliderRow rowRed, rowGreen, rowBlue, rowSat, rowHue, rowVal, rowCont, rowMin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new KcalStore(this);
        cfg = store.load();

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        col.setPadding(pad, dp(32), pad, dp(32));

        TextView title = new TextView(this);
        title.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_HeadlineMedium);
        title.setText(R.string.title);
        col.addView(title);

        status = new TextView(this);
        status.setText(R.string.status_checking);
        status.setPadding(0, dp(8), 0, dp(8));
        col.addView(status);

        // ---- preset ----
        addHeader(col, R.string.presets);
        presetGroup = new MaterialButtonToggleGroup(this);
        presetGroup.setSingleSelection(true);
        presetGroup.setSelectionRequired(false);
        String[] names = getResources().getStringArray(R.array.preset_names);
        for (int i = 0; i < presetIds.length; i++) {
            MaterialButton b = new MaterialButton(this, null,
                    com.google.android.material.R.attr.materialButtonOutlinedStyle);
            b.setId(android.view.View.generateViewId());
            b.setText(names[i]);
            b.setSingleLine(true);
            presetIds[i] = b.getId();
            presetGroup.addView(b, new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        presetGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (refreshing || !isChecked) return;
            for (int i = 0; i < presetIds.length; i++) {
                if (presetIds[i] == checkedId) {
                    applyPreset(i);
                    break;
                }
            }
        });
        col.addView(presetGroup);

        // ---- KCAL utama ----
        addHeader(col, R.string.category_main);
        enableSwitch = addSwitch(col, R.string.enable);
        enableSwitch.setOnCheckedChangeListener((v, checked) -> {
            if (refreshing) return;
            cfg.enabled = checked;
            updateControlsEnabled();
            submit();
        });
        invertSwitch = addSwitch(col, R.string.invert);
        invertSwitch.setOnCheckedChangeListener((v, checked) -> {
            if (refreshing) return;
            cfg.invert = checked;
            submit();
        });

        rowRed = addSlider(col, R.string.red, KcalConfig.CH_MIN, KcalConfig.CH_MAX,
                v -> { cfg.red = v; onRgbChanged(); });
        rowGreen = addSlider(col, R.string.green, KcalConfig.CH_MIN, KcalConfig.CH_MAX,
                v -> { cfg.green = v; onRgbChanged(); });
        rowBlue = addSlider(col, R.string.blue, KcalConfig.CH_MIN, KcalConfig.CH_MAX,
                v -> { cfg.blue = v; onRgbChanged(); });
        rowSat = addSlider(col, R.string.saturation, KcalConfig.SAT_MIN, KcalConfig.SAT_MAX,
                v -> { cfg.sat = v; submit(); });
        rowHue = addSlider(col, R.string.hue, KcalConfig.HUE_MIN, KcalConfig.HUE_MAX,
                v -> { cfg.hue = v; submit(); });
        rowVal = addSlider(col, R.string.value, KcalConfig.VAL_MIN, KcalConfig.VAL_MAX,
                v -> { cfg.val = v; submit(); });
        rowCont = addSlider(col, R.string.contrast, KcalConfig.CONT_MIN, KcalConfig.CONT_MAX,
                v -> { cfg.cont = v; submit(); });

        // ---- lanjutan ----
        addHeader(col, R.string.advanced);
        rowMin = addSlider(col, R.string.minimum, KcalConfig.MIN_MIN, KcalConfig.MIN_MAX,
                v -> { cfg.min = v; submit(); });

        resetButton = new MaterialButton(this, null,
                com.google.android.material.R.attr.materialButtonOutlinedStyle);
        resetButton.setText(R.string.reset);
        resetButton.setOnClickListener(v -> {
            cfg = new KcalConfig();
            refresh();
            submit();
        });
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        resetLp.topMargin = dp(16);
        col.addView(resetButton, resetLp);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(col);
        setContentView(scroll);

        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        store.setFailureListener(() -> main.post(this::toastWriteFailed));
        cfg = store.load();
        refresh();
        checkHook();
    }

    @Override
    protected void onPause() {
        store.setFailureListener(null);
        super.onPause();
    }

    /** Beri izin sekali lewat root, kirim setelan, lalu pastikan hook membalas (ack). */
    private void checkHook() {
        status.setText(R.string.status_checking);
        KcalStore.IO.execute(() -> {
            boolean root = RootShell.isRoot();
            if (root) store.ensureWriteSecure();

            String sent = store.push(store.load());
            int message;
            if (sent == null) {
                message = R.string.status_no_write;
            } else if (!root) {
                message = R.string.status_sent_no_root;
            } else {
                message = R.string.status_no_hook;
                for (int i = 0; i < 4; i++) {
                    try {
                        Thread.sleep(400);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                    if (sent.equals(store.readAck())) {
                        message = R.string.status_ok;
                        break;
                    }
                }
            }
            final int msg = message;
            final boolean writable = sent != null;
            main.post(() -> {
                available = writable;
                status.setText(msg);
                updateControlsEnabled();
            });
        });
    }

    // ------------------------------------------------------------ UI state

    private void submit() {
        store.submit(cfg);
    }

    private void onRgbChanged() {
        syncPresetHighlight();
        submit();
    }

    private void applyPreset(int index) {
        int[] p = KcalConfig.PRESETS[index];
        cfg.enabled = true;
        cfg.red = p[0];
        cfg.green = p[1];
        cfg.blue = p[2];
        refresh();
        submit();
    }

    /** Isi semua kontrol dari cfg tanpa memicu listener. */
    private void refresh() {
        refreshing = true;
        try {
            enableSwitch.setChecked(cfg.enabled);
            invertSwitch.setChecked(cfg.invert);
            rowRed.setValue(cfg.red);
            rowGreen.setValue(cfg.green);
            rowBlue.setValue(cfg.blue);
            rowSat.setValue(cfg.sat);
            rowHue.setValue(cfg.hue);
            rowVal.setValue(cfg.val);
            rowCont.setValue(cfg.cont);
            rowMin.setValue(cfg.min);
            syncPresetHighlight();
            updateControlsEnabled();
        } finally {
            refreshing = false;
        }
    }

    /** Kontrol hanya aktif bila setelan bisa ditulis DAN KCAL sedang di-enable (seperti app asli). */
    private void updateControlsEnabled() {
        boolean active = cfg.enabled && available;
        enableSwitch.setEnabled(available);
        resetButton.setEnabled(available);
        presetGroup.setEnabled(active);
        for (int i = 0; i < presetGroup.getChildCount(); i++) {
            presetGroup.getChildAt(i).setEnabled(active);
        }
        invertSwitch.setEnabled(active);
        rowRed.setEnabled(active);
        rowGreen.setEnabled(active);
        rowBlue.setEnabled(active);
        rowSat.setEnabled(active);
        rowHue.setEnabled(active);
        rowVal.setEnabled(active);
        rowCont.setEnabled(active);
        rowMin.setEnabled(active);
    }

    private void syncPresetHighlight() {
        int idx = KcalConfig.indexOfPreset(cfg.red, cfg.green, cfg.blue);
        boolean prev = refreshing;
        refreshing = true;
        try {
            if (idx >= 0) presetGroup.check(presetIds[idx]);
            else presetGroup.clearChecked();
        } finally {
            refreshing = prev;
        }
    }

    private void toastWriteFailed() {
        Toast.makeText(this, R.string.write_failed, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------- builders

    private MaterialSwitch addSwitch(LinearLayout parent, int textRes) {
        MaterialSwitch s = new MaterialSwitch(this);
        s.setText(textRes);
        s.setPadding(0, dp(8), 0, dp(8));
        parent.addView(s);
        return s;
    }

    private void addHeader(LinearLayout parent, int textRes) {
        TextView h = new TextView(this);
        h.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleSmall);
        h.setText(textRes);
        h.setPadding(0, dp(24), 0, dp(8));
        parent.addView(h);
    }

    private SliderRow addSlider(LinearLayout parent, int labelRes, int min, int max,
                                SliderRow.Listener listener) {
        SliderRow row = new SliderRow(this, getString(labelRes), min, max);
        row.setListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        parent.addView(row, lp);
        return row;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
