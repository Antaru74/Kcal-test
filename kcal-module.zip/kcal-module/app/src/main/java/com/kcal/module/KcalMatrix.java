package com.kcal.module;

/**
 * Mengubah {@link KcalConfig} menjadi satu matriks warna 4x4 untuk SurfaceFlinger
 * (float[16], urutan column-major; translasi di indeks 12..14), lewat
 * DisplayTransformManager.setColorMatrix().
 *
 * Ini EMULASI. Driver KCAL asli bekerja di blok PCC/PA hardware display; di sini efeknya
 * ditiru dengan transformasi linear. Asumsi pemetaan (silakan disetel di sini bila beda
 * dengan perilaku asli di perangkat):
 *  - RGB     : gain = max(nilai, min) / 256
 *  - min     : batas bawah gain RGB (mencegah layar terlalu gelap)
 *  - sat/val/cont : faktor = nilai / 255   (255 = netral, rentang ~0.50 .. 1.50)
 *  - hue     : 1536 satuan = 360 derajat, rotasi di sekitar sumbu abu-abu
 *  - invert  : out = 1 - in
 * Urutan penerapan: hue -> saturasi -> value -> kontras -> RGB -> invert.
 */
public final class KcalMatrix {

    private static final double LR = 0.213, LG = 0.715, LB = 0.072;

    private KcalMatrix() {
    }

    /** @return matriks, atau null bila KCAL mati / hasilnya identitas (artinya: hapus level). */
    public static float[] build(KcalConfig c) {
        if (c == null || !c.enabled) return null;

        double[] m = identity();
        m = mul(hue(c.hue), m);
        m = mul(saturation(c.sat / 255.0), m);
        m = mul(uniformScale(c.val / 255.0), m);
        m = mul(contrast(c.cont / 255.0), m);
        m = mul(rgbGain(gain(c.red, c.min), gain(c.green, c.min), gain(c.blue, c.min)), m);
        if (c.invert) m = mul(invert(), m);

        if (isIdentity(m)) return null;

        float[] out = new float[16];
        for (int col = 0; col < 4; col++) {
            for (int row = 0; row < 4; row++) {
                out[col * 4 + row] = (float) m[row * 4 + col];
            }
        }
        return out;
    }

    private static double gain(int v, int min) {
        return KcalConfig.clamp(Math.max(v, min), 0, 256) / 256.0;
    }

    // ---- 4x4 row-major: out = M * [r g b 1]^T ----

    private static double[] identity() {
        return new double[]{
                1, 0, 0, 0,
                0, 1, 0, 0,
                0, 0, 1, 0,
                0, 0, 0, 1};
    }

    /** a * b (b diterapkan lebih dulu). */
    private static double[] mul(double[] a, double[] b) {
        double[] r = new double[16];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                double s = 0;
                for (int k = 0; k < 4; k++) s += a[i * 4 + k] * b[k * 4 + j];
                r[i * 4 + j] = s;
            }
        }
        return r;
    }

    private static double[] hue(int hue) {
        double a = 2 * Math.PI * hue / 1536.0;
        double c = Math.cos(a), s = Math.sin(a);
        return new double[]{
                LR + c * (1 - LR) - s * LR, LG - c * LG - s * LG, LB - c * LB + s * (1 - LB), 0,
                LR - c * LR + s * 0.143, LG + c * (1 - LG) + s * 0.140, LB - c * LB - s * 0.283, 0,
                LR - c * LR - s * (1 - LR), LG - c * LG + s * LG, LB + c * (1 - LB) + s * LB, 0,
                0, 0, 0, 1};
    }

    private static double[] saturation(double s) {
        double ir = 1 - s;
        return new double[]{
                LR * ir + s, LG * ir, LB * ir, 0,
                LR * ir, LG * ir + s, LB * ir, 0,
                LR * ir, LG * ir, LB * ir + s, 0,
                0, 0, 0, 1};
    }

    private static double[] uniformScale(double k) {
        return rgbGain(k, k, k);
    }

    private static double[] rgbGain(double r, double g, double b) {
        return new double[]{
                r, 0, 0, 0,
                0, g, 0, 0,
                0, 0, b, 0,
                0, 0, 0, 1};
    }

    /** out = (in - 0.5) * k + 0.5 */
    private static double[] contrast(double k) {
        double t = 0.5 * (1 - k);
        return new double[]{
                k, 0, 0, t,
                0, k, 0, t,
                0, 0, k, t,
                0, 0, 0, 1};
    }

    private static double[] invert() {
        return new double[]{
                -1, 0, 0, 1,
                0, -1, 0, 1,
                0, 0, -1, 1,
                0, 0, 0, 1};
    }

    private static boolean isIdentity(double[] m) {
        double[] id = identity();
        for (int i = 0; i < 16; i++) {
            if (Math.abs(m[i] - id[i]) > 1e-4) return false;
        }
        return true;
    }
}
