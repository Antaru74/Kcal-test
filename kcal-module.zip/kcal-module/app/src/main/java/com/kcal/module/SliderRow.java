package com.kcal.module;

import android.content.Context;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.slider.Slider;

/** Baris berisi label, nilai saat ini, dan Slider bulat (step 1). */
final class SliderRow extends LinearLayout {

    interface Listener {
        /** Dipanggil hanya saat nilai diubah pengguna, bukan lewat setValue(). */
        void onValue(int value);
    }

    private final TextView valueView;
    private final Slider slider;
    private final int min;
    private final int max;
    private Listener listener;

    SliderRow(Context context, CharSequence label, int min, int max) {
        super(context);
        this.min = min;
        this.max = max;
        setOrientation(VERTICAL);

        LinearLayout head = new LinearLayout(context);
        head.setOrientation(HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = new TextView(context);
        name.setText(label);
        head.addView(name, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));

        valueView = new TextView(context);
        valueView.setText(String.valueOf(min));
        head.addView(valueView, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        slider = new Slider(context);
        slider.setValueFrom(min);
        slider.setValueTo(max);
        slider.setStepSize(1f);
        slider.setValue(min);
        slider.addOnChangeListener((s, v, fromUser) -> {
            valueView.setText(String.valueOf((int) v));
            if (fromUser && listener != null) listener.onValue((int) v);
        });

        addView(head, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        addView(slider, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
    }

    void setListener(Listener listener) {
        this.listener = listener;
    }

    void setValue(int value) {
        int v = Math.max(min, Math.min(max, value));
        slider.setValue(v);
        valueView.setText(String.valueOf(v));
    }

    int getValue() {
        return (int) slider.getValue();
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if (slider != null) slider.setEnabled(enabled);
        setAlpha(enabled ? 1f : 0.5f);
    }
}
