package com.kcal.module;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/**
 * Satu proses {@code su} yang dipakai ulang, supaya menggeser slider tidak
 * membuka su baru setiap kali. Semua pemanggilan harus dari thread background
 * (lihat {@link KcalStore#IO}).
 */
final class RootShell {

    static final class Result {
        final int code;
        final String out;

        Result(int code, String out) {
            this.code = code;
            this.out = out;
        }

        boolean ok() {
            return code == 0;
        }
    }

    private static final String MARK = "__KCAL_RC__";

    private static Process process;
    private static BufferedWriter stdin;
    private static BufferedReader stdout;

    private RootShell() {
    }

    private static boolean ensureOpen() {
        if (process != null) {
            try {
                process.exitValue(); // sudah mati -> buka ulang
                close();
            } catch (IllegalThreadStateException stillAlive) {
                return true;
            }
        }
        try {
            process = new ProcessBuilder("su").redirectErrorStream(true).start();
            stdin = new BufferedWriter(new OutputStreamWriter(process.getOutputStream()));
            stdout = new BufferedReader(new InputStreamReader(process.getInputStream()));
            return true;
        } catch (IOException e) {
            close();
            return false;
        }
    }

    static synchronized Result run(String command) {
        if (!ensureOpen()) {
            return new Result(-1, "su tidak tersedia");
        }
        try {
            stdin.write(command);
            stdin.write("\necho " + MARK + "$?\n");
            stdin.flush();

            StringBuilder out = new StringBuilder();
            String line;
            while ((line = stdout.readLine()) != null) {
                int i = line.indexOf(MARK);
                if (i >= 0) {
                    if (i > 0) {
                        out.append(line, 0, i).append('\n');
                    }
                    int code = Integer.parseInt(line.substring(i + MARK.length()).trim());
                    return new Result(code, out.toString().trim());
                }
                out.append(line).append('\n');
            }
        } catch (IOException | NumberFormatException ignored) {
            // jatuh ke bawah: shell dianggap putus
        }
        close();
        return new Result(-1, "shell root terputus");
    }

    static synchronized boolean isRoot() {
        Result r = run("id -u");
        return r.ok() && "0".equals(r.out);
    }

    private static void close() {
        try {
            if (stdin != null) stdin.close();
        } catch (IOException ignored) {
        }
        if (process != null) process.destroy();
        process = null;
        stdin = null;
        stdout = null;
    }
}
