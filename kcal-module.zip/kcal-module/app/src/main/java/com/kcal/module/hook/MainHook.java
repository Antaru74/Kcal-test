package com.kcal.module.hook;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import com.kcal.module.KcalConfig;
import com.kcal.module.KcalMatrix;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Hook di system_server (scope "android").
 *
 * Menangkap instance DisplayTransformManager (kelas yang sama dipakai Night Light,
 * Invert Colors, dan LiveDisplay) lalu memasang satu matriks warna di levelnya sendiri.
 * Matriks dibangun dari Settings.Secure "kcal_module_config" yang ditulis app modul,
 * dan diterapkan ulang saat setelan berubah serta saat BOOT_COMPLETED.
 * Setelah berhasil, hook menulis balik string konfigurasi ke "kcal_module_ack"
 * supaya app bisa memastikan hook benar-benar aktif.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "[KcalModule] ";
    private static final String DTM_CLASS = "com.android.server.display.color.DisplayTransformManager";

    /**
     * Level matriks milik modul. Matriks tiap level disusun berurutan:
     * Night Light 100, white balance 125, saturasi 150, grayscale 200, invert 300.
     * LiveDisplay Lineage memakai 101 dan 201, jadi 160 aman dari bentrok.
     */
    private static final int LEVEL_KCAL = 160;

    private static Object dtm;
    private static Context context;
    private static boolean observerRegistered;
    private static boolean receiverRegistered;
    private static boolean loggedFirstApply;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"android".equals(lpparam.packageName)) return;

        try {
            Class<?> cls = XposedHelpers.findClassIfExists(DTM_CLASS, lpparam.classLoader);
            if (cls == null) {
                XposedBridge.log(TAG + "kelas tidak ditemukan: " + DTM_CLASS
                        + " (ROM ini mungkin memindahkan/menggantinya)");
                return;
            }
            XposedBridge.hookAllConstructors(cls, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    dtm = param.thisObject;
                    onReady();
                }
            });
            XposedBridge.log(TAG + "hook terpasang, menunggu DisplayTransformManager dibuat");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "gagal memasang hook: " + t);
        }
    }

    private static synchronized void onReady() {
        try {
            if (context == null) {
                Object thread = XposedHelpers.callStaticMethod(
                        XposedHelpers.findClass("android.app.ActivityThread", null),
                        "currentActivityThread");
                context = (Context) XposedHelpers.callMethod(thread, "getSystemContext");
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "gagal mengambil system context: " + t);
            return;
        }
        registerBootReceiver();
        registerObserver();
        applyFromSettings("ready");
    }

    private static void registerBootReceiver() {
        if (receiverRegistered) return;
        try {
            context.registerReceiver(new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent intent) {
                    // Pasang observer lagi bila registrasi awal gagal karena provider belum siap.
                    registerObserver();
                    applyFromSettings("boot_completed");
                }
            }, new IntentFilter(Intent.ACTION_BOOT_COMPLETED));
            receiverRegistered = true;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "gagal memasang receiver boot: " + t);
        }
    }

    private static synchronized void registerObserver() {
        if (observerRegistered || context == null) return;
        try {
            context.getContentResolver().registerContentObserver(
                    Settings.Secure.getUriFor(KcalConfig.SETTING_KEY), false,
                    new ContentObserver(new Handler(Looper.getMainLooper())) {
                        @Override
                        public void onChange(boolean selfChange) {
                            applyFromSettings("changed");
                        }
                    });
            observerRegistered = true;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "gagal memasang observer (akan dicoba lagi saat boot): " + t);
        }
    }

    private static synchronized void applyFromSettings(String why) {
        if (dtm == null || context == null) return;
        try {
            String raw = Settings.Secure.getString(context.getContentResolver(), KcalConfig.SETTING_KEY);
            if (raw == null) return; // belum pernah diatur: jangan menyentuh apa pun

            KcalConfig cfg = KcalConfig.parse(raw);
            if (cfg == null) {
                XposedBridge.log(TAG + "konfigurasi tidak valid: " + raw);
                return;
            }

            // null = hapus level ini dari komposisi (KCAL mati / hasil identitas).
            float[] matrix = KcalMatrix.build(cfg);
            XposedHelpers.callMethod(dtm, "setColorMatrix",
                    new Class<?>[]{int.class, float[].class}, LEVEL_KCAL, matrix);

            Settings.Secure.putString(context.getContentResolver(), KcalConfig.SETTING_ACK, raw);

            if (!loggedFirstApply) {
                loggedFirstApply = true;
                XposedBridge.log(TAG + "matriks diterapkan (" + why + "), enabled=" + cfg.enabled);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "gagal menerapkan (" + why + "): " + t);
        }
    }
}
