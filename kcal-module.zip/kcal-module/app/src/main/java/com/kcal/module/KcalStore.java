package com.kcal.module;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.util.Log;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Menyimpan setelan KCAL (SharedPreferences, untuk UI) dan meneruskannya ke hook
 * system_server lewat Settings.Secure. Hook membaca setelan yang sama saat boot,
 * jadi tidak perlu receiver boot atau root per perubahan.
 */
final class KcalStore {

    static final ExecutorService IO = Executors.newSingleThreadExecutor();

    private static final String TAG = "KcalModule";
    private static final String PREFS = "kcal";
    private static final String K_ENABLE = "kcal_enable";
    private static final String K_RED = "kcal_red";
    private static final String K_GREEN = "kcal_green";
    private static final String K_BLUE = "kcal_blue";
    private static final String K_MIN = "kcal_min";
    private static final String K_SAT = "kcal_sat";
    private static final String K_HUE = "kcal_hue";
    private static final String K_VAL = "kcal_val";
    private static final String K_CONT = "kcal_cont";
    private static final String K_INVERT = "kcal_invert";

    private final Context context;
    private final SharedPreferences prefs;
    private final AtomicReference<KcalConfig> pending = new AtomicReference<>();
    private volatile Runnable onFailure;

    KcalStore(Context ctx) {
        Context app = ctx.getApplicationContext();
        context = app != null ? app : ctx;
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    void setFailureListener(Runnable r) {
        onFailure = r;
    }

    // ------------------------------------------------------------ penyimpanan

    KcalConfig load() {
        KcalConfig c = new KcalConfig();
        c.enabled = prefs.getBoolean(K_ENABLE, false);
        c.invert = prefs.getBoolean(K_INVERT, false);
        c.red = KcalConfig.clamp(prefs.getInt(K_RED, KcalConfig.CH_DEF), KcalConfig.CH_MIN, KcalConfig.CH_MAX);
        c.green = KcalConfig.clamp(prefs.getInt(K_GREEN, KcalConfig.CH_DEF), KcalConfig.CH_MIN, KcalConfig.CH_MAX);
        c.blue = KcalConfig.clamp(prefs.getInt(K_BLUE, KcalConfig.CH_DEF), KcalConfig.CH_MIN, KcalConfig.CH_MAX);
        c.min = KcalConfig.clamp(prefs.getInt(K_MIN, KcalConfig.MIN_DEF), KcalConfig.MIN_MIN, KcalConfig.MIN_MAX);
        c.sat = KcalConfig.clamp(prefs.getInt(K_SAT, KcalConfig.SAT_DEF), KcalConfig.SAT_MIN, KcalConfig.SAT_MAX);
        c.hue = KcalConfig.clamp(prefs.getInt(K_HUE, KcalConfig.HUE_DEF), KcalConfig.HUE_MIN, KcalConfig.HUE_MAX);
        c.val = KcalConfig.clamp(prefs.getInt(K_VAL, KcalConfig.VAL_DEF), KcalConfig.VAL_MIN, KcalConfig.VAL_MAX);
        c.cont = KcalConfig.clamp(prefs.getInt(K_CONT, KcalConfig.CONT_DEF), KcalConfig.CONT_MIN, KcalConfig.CONT_MAX);
        return c;
    }

    private void save(KcalConfig c) {
        prefs.edit()
                .putBoolean(K_ENABLE, c.enabled)
                .putBoolean(K_INVERT, c.invert)
                .putInt(K_RED, c.red)
                .putInt(K_GREEN, c.green)
                .putInt(K_BLUE, c.blue)
                .putInt(K_MIN, c.min)
                .putInt(K_SAT, c.sat)
                .putInt(K_HUE, c.hue)
                .putInt(K_VAL, c.val)
                .putInt(K_CONT, c.cont)
                .apply();
    }

    // ----------------------------------------------------------- kirim ke hook

    /**
     * Simpan lalu kirim ke hook. Aman dipanggil berkali-kali saat slider digeser:
     * pengiriman yang menumpuk digabung, hanya nilai terbaru yang dikirim.
     */
    void submit(KcalConfig c) {
        pending.set(c.copy());
        IO.execute(this::drain);
    }

    private void drain() {
        KcalConfig c = pending.getAndSet(null);
        if (c == null) return;
        save(c);
        if (push(c) == null) {
            Runnable r = onFailure;
            if (r != null) r.run();
        }
    }

    boolean hasWriteSecure() {
        return context.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Beri izin WRITE_SECURE_SETTINGS lewat root (cukup sekali). */
    void ensureWriteSecure() {
        if (!hasWriteSecure()) {
            RootShell.Result r = RootShell.run("pm grant " + context.getPackageName()
                    + " android.permission.WRITE_SECURE_SETTINGS");
            if (!r.ok()) Log.w(TAG, "pm grant gagal: " + r.out);
        }
    }

    /**
     * Tulis konfigurasi ke Settings.Secure. Bila izin belum ada, jatuh ke
     * {@code settings put} lewat root.
     *
     * @return string yang dikirim (dipakai untuk mencocokkan ack dari hook), atau null bila gagal
     */
    String push(KcalConfig c) {
        String v = c.serialize(System.currentTimeMillis());
        try {
            if (Settings.Secure.putString(context.getContentResolver(), KcalConfig.SETTING_KEY, v)) {
                return v;
            }
        } catch (SecurityException e) {
            Log.w(TAG, "Tidak ada WRITE_SECURE_SETTINGS, pakai root");
        }
        RootShell.Result r = RootShell.run(
                "settings put secure " + KcalConfig.SETTING_KEY + " '" + v + "'");
        return r.ok() ? v : null;
    }

    /** Baca balasan hook (butuh root, karena Settings.Secure kustom tidak bisa dibaca app biasa). */
    String readAck() {
        RootShell.Result r = RootShell.run("settings get secure " + KcalConfig.SETTING_ACK);
        return r.ok() ? r.out : null;
    }
}
