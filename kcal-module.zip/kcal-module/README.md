# KCAL Module (LSPosed, portabel)

Port fitur KCAL dari app Clover menjadi modul LSPosed yang **tidak butuh driver kernel**.
Di Clover, KCAL hidup di dalam `msm_drm.ko` (node `/sys/devices/platform/kcal_ctrl.0`), jadi hanya jalan di ROM yang
membawa modul itu. Modul ini meniru efeknya lewat color matrix framework, sehingga jalan di ROM apa pun
(dirancang untuk crDroid di Poco F6 / peridot).

> Ini EMULASI, bukan KCAL hardware. Lihat "Batasan" di bawah.

## Build
1. Buka folder ini di Android Studio (JDK 17), tunggu Gradle sync.
2. Build > Build APK(s), atau di terminal: `gradle wrapper` sekali, lalu `./gradlew assembleRelease`.
   APK: `app/build/outputs/apk/release/app-release.apk` (ditandatangani debug key, langsung bisa di-install).
3. Kalau repo `https://api.xposed.info/` tidak bisa diakses: unduh `api-82.jar`, taruh di `app/libs/`, ganti
   `compileOnly 'de.robv.android.xposed:api:82'` dengan `compileOnly files('libs/api-82.jar')`, hapus repo xposed.info
   di `settings.gradle`.

## Pasang
1. Install APK, buka sekali, **beri izin root** saat diminta (dipakai satu kali untuk
   `pm grant ... WRITE_SECURE_SETTINGS`; setelah itu geser slider tidak memakai root lagi).
2. LSPosed > Modul > KCAL Module > aktifkan, centang scope **System Framework**.
3. Reboot. Buka app: status harus "Hook aktif". LSPosed > Log juga harus memuat `[KcalModule] hook terpasang`
   dan `matriks diterapkan`.

## Cara kerja
- App menyimpan setelan lalu menulisnya ke `Settings.Secure` key `kcal_module_config`
  (format `v1;enabled;r;g;b;min;sat;hue;val;cont;invert;stamp`).
- Hook di system_server menangkap `DisplayTransformManager`, membaca key itu (saat boot, saat berubah, dan saat
  BOOT_COMPLETED), membangun satu matriks 4x4 (`KcalMatrix`), dan memasangnya di level 160 lewat
  `setColorMatrix(160, matrix)`. Matriks level lain (Night Light, Invert Colors, LiveDisplay) tetap bekerja dan
  digabung oleh framework.
- Hook membalas lewat key `kcal_module_ack`; itu yang dicek app untuk status "Hook aktif".
- Restore saat boot otomatis, karena hook membaca setelan yang tersimpan.

Rentang dan default sama dengan app Clover: RGB 0-256, min 35-256, sat/val/kontras 128-383 (netral 255),
hue 0-1536. Preset: Standar 256/256/256, Hangat 256/248/225, Dingin 232/244/256, Malam 256/230/190.

## Batasan (baca ini)
- **Pemetaan nilai adalah asumsi** (driver aslinya tidak bisa saya baca): gain RGB = max(nilai, min)/256;
  sat/val/kontras = nilai/255; hue 1536 = 360 derajat; urutan hue > sat > value > kontras > RGB > invert.
  Semuanya ada di `KcalMatrix.java`, mudah disetel kalau hasilnya terasa beda.
- Matriks diterapkan SurfaceFlinger pada hasil komposisi, bukan di blok PCC/PA display. Hasil mirip, tidak identik
  (terutama kontras dan `min`).
- Belum diuji di perangkat. Hook memakai kelas internal `com.android.server.display.color.DisplayTransformManager`;
  kalau ROM memindahkannya, LSPosed Log akan menulis "kelas tidak ditemukan".
- Kalau Night Light / Invert Colors / mode warna HyperOS ikut aktif, hasilnya adalah gabungan semuanya.

## Uji logika tanpa perangkat
`KcalConfig` dan `KcalMatrix` adalah Java murni (tanpa API Android), jadi bisa dikompilasi dan diuji di JVM biasa.
